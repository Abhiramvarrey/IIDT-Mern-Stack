from django.shortcuts import render
from django.contrib.auth import login
from .forms import newuser


# Create your views here.
def register(request):
    form = newuser()
    if request.method == 'POST':
        form = newuser(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return render(request, 'sucess.html')
    return render(request, 'register.html', context={'register_form': form})


def base(request):
    return render(request, 'base.html')

from django.contrib.auth import login
from django.shortcuts import render, redirect
from .forms import NewUserForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required

from .models import UserProfile


# Create your views here.
def home(request):
    return  render(request,'login.html')

def register_user(request):
    if request.method=='POST':
        form = NewUserForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request,f"Hello {username}, your account has been created please login")
            return redirect(login)
        else:
            form = NewUserForm()
    form = NewUserForm()
    return  render(request,'register.html',{'register_form':form})


from django.shortcuts import render, redirect
from .forms import ProfileImageForm
@login_required
def profile(request):
    try:
        profile = UserProfile.objects.get(user=request.user)
    except UserProfile.DoesNotExist:
        profile = UserProfile.objects.create(user=request.user)

    if request.method == 'POST':
        form = ProfileImageForm(request.POST, request.FILES)
        if form.is_valid():
            if 'profile_image' in form.cleaned_data:
                profile.profile_image = form.cleaned_data['profile_image']
                profile.save()
            return redirect('profile')
    else:
        form = ProfileImageForm()
    return render(request, 'profile.html', {'form': form, 'profile': profile})

